/* Copyright 2026 Marimo. All rights reserved. */
import { EditorView } from "@codemirror/view";
import {
  type LanguageServerClient,
  languageServerWithClient,
} from "@marimo-team/codemirror-languageserver";
import { beforeEach, describe, expect, it, type Mocked, vi } from "vitest";
import * as LSP from "vscode-languageserver-protocol";
import { cellId } from "@/__tests__/branded";
import type { CellId } from "@/core/cells/ids";
import { initialNotebookState, notebookAtom } from "@/core/cells/cells";
import { createCell } from "@/core/cells/types";
import { store } from "@/core/state/jotai";
import { MultiColumn } from "@/utils/id-tree";
import { topologicalCodesAtom } from "../../copilot/getCodes";
import { lspWorkspaceAtom } from "@/core/saving/file-state";
import { languageAdapterState } from "../../language/extension";
import { PythonLanguageAdapter } from "../../language/languages/python";
import { languageMetadataField } from "../../language/metadata";
import { createNotebookLens } from "../lens";
import { NotebookLanguageServerClient } from "../notebook-lsp";
import {
  CellDocumentUri,
  type ClientNotification,
  type ILanguageServerClient,
} from "../types";

const Cells = {
  cell1: cellId("cell1"),
  cell2: cellId("cell2"),
  cell3: cellId("cell3"),
};

type TestLanguageServerClient = ILanguageServerClient & {
  notify: (method: string, params: unknown) => Promise<void>;
  processNotification: (notification: ClientNotification) => void;
};

type GetNotebookEditors = () => Record<CellId, EditorView | null | undefined>;

function replaceNotebookEditors(
  client: NotebookLanguageServerClient,
  getNotebookEditors: GetNotebookEditors,
): void {
  const mutableClient = client as unknown as {
    getNotebookEditors: GetNotebookEditors;
  };
  mutableClient.getNotebookEditors = getNotebookEditors;
}

function isPublishDiagnosticsNotification(
  notification: ClientNotification,
): notification is {
  method: "textDocument/publishDiagnostics";
  params: LSP.PublishDiagnosticsParams;
} {
  return (
    notification.method === "textDocument/publishDiagnostics" &&
    typeof notification.params === "object" &&
    notification.params !== null &&
    "uri" in notification.params &&
    typeof notification.params.uri === "string" &&
    "diagnostics" in notification.params &&
    Array.isArray(notification.params.diagnostics)
  );
}

describe("merged document with unmounted editors", () => {
  it("should include the code of cells whose editors are not mounted", () => {
    store.set(notebookAtom, {
      ...initialNotebookState(),
      cellIds: MultiColumn.from([[Cells.cell1, Cells.cell2]]),
      cellData: {
        [Cells.cell1]: createCell({ id: Cells.cell1, code: "import math" }),
        [Cells.cell2]: createCell({
          id: Cells.cell2,
          code: "print(math.sqrt(4))",
        }),
      },
    });

    const { cellIds, codes } = store.get(topologicalCodesAtom);
    const lens = createNotebookLens(cellIds, codes);

    expect(lens.mergedText).toContain("import math");
    expect(lens.mergedText).toContain("print(math.sqrt(4))");
  });
});

describe("createNotebookLens", () => {
  it("should produce correct lens for same inputs", () => {
    // Use unique content for this test
    const cellIds: CellId[] = [Cells.cell1, Cells.cell2];
    const codes: Record<CellId, string> = {
      [Cells.cell1]: "unique_memo_test_line1",
      [Cells.cell2]: "unique_memo_test_line2",
    };

    const lens1 = createNotebookLens(cellIds, codes);
    const lens2 = createNotebookLens(cellIds, codes);

    // Same inputs should produce equivalent lens (same merged text)
    expect(lens1.mergedText).toBe(lens2.mergedText);
    expect(lens1.cellIds).toEqual(lens2.cellIds);

    // Different content should produce a different lens
    const differentCodes: Record<CellId, string> = {
      [Cells.cell1]: "unique_memo_different",
      [Cells.cell2]: "unique_memo_content",
    };
    const lens3 = createNotebookLens(cellIds, differentCodes);
    expect(lens3.mergedText).not.toBe(lens1.mergedText);
  });

  it("should calculate correct line offsets", () => {
    const cellIds: CellId[] = [Cells.cell1, Cells.cell2, Cells.cell3];
    const codes: Record<CellId, string> = {
      [Cells.cell1]: "fileA\nfileB",
      [Cells.cell2]: "line1\nline2",
      [Cells.cell3]: "fileC",
    };
    const lens = createNotebookLens(cellIds, codes);

    const pos: LSP.Position = { line: 0, character: 0 };
    const transformed = lens.transformPosition(pos, Cells.cell2);
    expect(transformed.line).toBe(2); // After fileA\nfileB
    expect(transformed.character).toBe(0);
  });

  it("order of code should not matter", () => {
    const cellIds: CellId[] = [Cells.cell1, Cells.cell2];
    let codes: Record<CellId, string> = {
      [Cells.cell1]: "before\ntext",
      [Cells.cell2]: "cell1\ncell2",
    };
    let lens = createNotebookLens(cellIds, codes);
    expect(lens.mergedText).toBe("before\ntext\ncell1\ncell2");

    // Swap them around
    codes = {
      [Cells.cell2]: "cell1\ncell2",
      [Cells.cell1]: "before\ntext",
    };
    lens = createNotebookLens(cellIds, codes);
    expect(lens.mergedText).toBe("before\ntext\ncell1\ncell2");
  });

  it("should transform ranges to merged doc", () => {
    const cellIds: CellId[] = [Cells.cell1, Cells.cell2];
    const codes: Record<CellId, string> = {
      [Cells.cell1]: "before\ntext",
      [Cells.cell2]: "cell1\ncell2",
    };
    const lens = createNotebookLens(cellIds, codes);

    const range: LSP.Range = {
      start: { line: 0, character: 0 },
      end: { line: 1, character: 5 },
    };

    const transformed = lens.transformRange(range, Cells.cell2);
    expect(transformed.start.line).toBe(2);
    expect(transformed.end.line).toBe(3);
  });

  it("should reverse ranges from merged doc", () => {
    const cellIds: CellId[] = [Cells.cell1, Cells.cell2];
    const codes: Record<CellId, string> = {
      [Cells.cell1]: "header",
      [Cells.cell2]: "test\ncode",
    };
    const lens = createNotebookLens(cellIds, codes);

    const range: LSP.Range = {
      start: { line: 1, character: 0 },
      end: { line: 2, character: 4 },
    };

    const reversed = lens.reverseRange(range, Cells.cell2);
    expect(reversed.start.line).toBe(0);
    expect(reversed.end.line).toBe(1);
  });

  it("should check if range is within cell bounds", () => {
    const cellIds: CellId[] = [Cells.cell1];
    const codes: Record<CellId, string> = {
      [Cells.cell1]: "line1\nline2\nline3",
    };
    const lens = createNotebookLens(cellIds, codes);

    expect(
      lens.isInRange(
        {
          start: { line: 0, character: 0 },
          end: { line: 2, character: 5 },
        },
        Cells.cell1,
      ),
    ).toBe(true);

    // This triggers the cross-cell diagnostic warning (start in range, end outside)
    expect(
      lens.isInRange(
        {
          start: { line: 0, character: 0 },
          end: { line: 3, character: 0 },
        },
        Cells.cell1,
      ),
    ).toBe(false);
  });

  it("should detect cross-cell diagnostics where start is in range but end is outside", () => {
    const cellIds: CellId[] = [Cells.cell1, Cells.cell2];
    const codes: Record<CellId, string> = {
      [Cells.cell1]: "line1\nline2",
      [Cells.cell2]: "line3",
    };
    const lens = createNotebookLens(cellIds, codes);

    // Range that starts in cell1 (line 1) but ends in cell2 (line 2 = first line of cell2)
    // This should return false and log a warning
    const crossCellRange = {
      start: { line: 1, character: 0 }, // line 1 is in cell1
      end: { line: 2, character: 0 }, // line 2 is in cell2
    };

    expect(lens.isInRange(crossCellRange, Cells.cell1)).toBe(false);
  });

  it("should join all code into merged text", () => {
    const cellIds: CellId[] = [Cells.cell1, Cells.cell2, Cells.cell3];
    const codes: Record<CellId, string> = {
      [Cells.cell1]: "a",
      [Cells.cell2]: "cell",
      [Cells.cell3]: "b",
    };
    const lens = createNotebookLens(cellIds, codes);

    expect(lens.mergedText).toBe("a\ncell\nb");
  });

  it("should handle empty cells", () => {
    const cellIds: CellId[] = [Cells.cell1, Cells.cell2];
    const codes: Record<CellId, string> = {
      [Cells.cell1]: "",
      [Cells.cell2]: "code",
    };
    const lens = createNotebookLens(cellIds, codes);

    const pos: LSP.Position = { line: 0, character: 0 };
    const transformed = lens.transformPosition(pos, Cells.cell2);
    expect(transformed.line).toBe(1);
  });

  it("should handle cells with multiple lines", () => {
    const cellIds: CellId[] = [Cells.cell1, Cells.cell2];
    const codes: Record<CellId, string> = {
      [Cells.cell1]: "line1\nline2\nline3",
      [Cells.cell2]: "test",
    };
    const lens = createNotebookLens(cellIds, codes);

    const pos: LSP.Position = { line: 0, character: 0 };
    const transformed = lens.transformPosition(pos, Cells.cell2);
    expect(transformed.line).toBe(3);
  });

  it("should clip range and text to cell boundaries", () => {
    const cellIds: CellId[] = [Cells.cell1, Cells.cell2, Cells.cell3];
    const codes: Record<CellId, string> = {
      [Cells.cell1]: "line1\nline2",
      [Cells.cell2]: "line3\nline4\nline5",
      [Cells.cell3]: "line6\nline7",
    };
    const lens = createNotebookLens(cellIds, codes);

    // Assume the line length does not change
    const newText = "a\nb\nc\nd\ne\nf\ng";

    const edits = lens.getEditsForNewText(newText);

    expect(edits).toMatchInlineSnapshot(`
      [
        {
          "cellId": "cell1",
          "text": "a
      b",
        },
        {
          "cellId": "cell2",
          "text": "c
      d
      e",
        },
        {
          "cellId": "cell3",
          "text": "f
      g",
        },
      ]
    `);
  });
});

describe("NotebookLanguageServerClient", () => {
  let mockClient: Mocked<TestLanguageServerClient>;
  let notebookClient: NotebookLanguageServerClient;
  let notifyMock: Mocked<TestLanguageServerClient>["notify"];

  beforeEach(() => {
    mockClient = {
      ready: true,
      capabilities: {},
      initializePromise: Promise.resolve(),
      clientCapabilities: {},
      hasCapability: vi.fn().mockReturnValue(false),
      completionItemResolve: vi.fn(),
      codeActionResolve: vi.fn(),
      initialize: vi.fn(),
      close: vi.fn(),
      onNotification: vi.fn(),
      textDocumentDidOpen: vi.fn(),
      textDocumentDidChange: vi.fn(),
      textDocumentDidClose: vi.fn(),
      textDocumentWillSave: vi.fn(),
      textDocumentWillSaveWaitUntil: vi.fn(),
      textDocumentDidSave: vi.fn(),
      textDocumentHover: vi.fn(),
      textDocumentCompletion: vi.fn(),
      textDocumentDefinition: vi.fn(),
      textDocumentPrepareRename: vi.fn(),
      textDocumentCodeAction: vi.fn(),
      textDocumentSignatureHelp: vi.fn(),
      textDocumentRename: vi.fn(),
      processNotification: vi.fn(),
      notify: vi.fn(),
    };
    notifyMock = mockClient.notify;

    // Mock the atom instead of the instance method
    vi.spyOn(store, "get").mockImplementation((atom) => {
      if (atom === topologicalCodesAtom) {
        return {
          cellIds: [Cells.cell1, Cells.cell2, Cells.cell3],
          codes: {
            [Cells.cell1]: "# this is a comment",
            [Cells.cell2]: "import math\nimport numpy",
            [Cells.cell3]: "print(math.sqrt(4))",
          },
        };
      }
      if (atom === lspWorkspaceAtom) {
        return {
          rootUri: "file:///project",
          documentUri: "file:///project/__marimo_notebook__.py",
        };
      }
      return undefined;
    });

    notebookClient = new NotebookLanguageServerClient(
      mockClient,
      {},
      () => ({}),
    );
  });

  describe("live editor snapshots", () => {
    function createEditor(code: string) {
      return new EditorView({
        doc: code,
        extensions: [
          languageAdapterState.init(() => new PythonLanguageAdapter()),
          languageMetadataField.init(() => ({})),
        ],
      });
    }

    it("sends edits and their removal without invalidating the notebook atom", async () => {
      const cachedCodes = store.get(topologicalCodesAtom);
      const editor = createEditor("print(math.sqrt(4))");
      replaceNotebookEditors(notebookClient, () => ({ [Cells.cell3]: editor }));
      const uri = CellDocumentUri.of(Cells.cell3);
      try {
        await notebookClient.textDocumentDidOpen({
          textDocument: {
            uri,
            languageId: "python",
            version: 1,
            text: editor.state.doc.toString(),
          },
        });
        for (const [index, code] of [
          "math.missing()",
          "print(math.sqrt(4))",
        ].entries()) {
          editor.dispatch({
            changes: { from: 0, to: editor.state.doc.length, insert: code },
          });
          await notebookClient.textDocumentDidChange({
            textDocument: { uri, version: index + 2 },
            contentChanges: [{ text: code }],
          });
          expect(store.get(topologicalCodesAtom)).toEqual(cachedCodes);
          expect(mockClient.textDocumentDidChange).toHaveBeenNthCalledWith(
            index + 1,
            {
              textDocument: {
                uri: notebookClient.documentUri,
                version: index + 2,
              },
              contentChanges: [
                {
                  text: `# this is a comment\nimport math\nimport numpy\n${code}`,
                },
              ],
            },
          );
        }
      } finally {
        editor.destroy();
      }
    });

    it("syncs pending edits before completion and uses their updated line offsets", async () => {
      const editor = createEditor("import math\nimport numpy");
      replaceNotebookEditors(notebookClient, () => ({ [Cells.cell2]: editor }));
      try {
        await notebookClient.textDocumentDidOpen({
          textDocument: {
            uri: CellDocumentUri.of(Cells.cell2),
            languageId: "python",
            version: 1,
            text: editor.state.doc.toString(),
          },
        });
        editor.dispatch({
          changes: { from: editor.state.doc.length, insert: "\nextra = 1" },
        });
        mockClient.textDocumentCompletion.mockImplementation(async () => {
          expect(mockClient.textDocumentDidChange).toHaveBeenCalledWith({
            textDocument: { uri: notebookClient.documentUri, version: 2 },
            contentChanges: [
              {
                text: "# this is a comment\nimport math\nimport numpy\nextra = 1\nprint(math.sqrt(4))",
              },
            ],
          });
          return null;
        });
        const params: LSP.CompletionParams = {
          textDocument: { uri: CellDocumentUri.of(Cells.cell3) },
          position: { line: 0, character: 11 },
        };
        await notebookClient.textDocumentCompletion(params);
        expect(mockClient.textDocumentCompletion).toHaveBeenCalledWith({
          textDocument: { uri: notebookClient.documentUri },
          position: { line: 4, character: 11 },
        });
        await notebookClient.textDocumentCompletion(params);
        expect(mockClient.textDocumentDidChange).toHaveBeenCalledTimes(1);
      } finally {
        editor.destroy();
      }
    });
  });

  describe("document lifecycle", () => {
    it("maps cell opens and closes to the merged notebook document", async () => {
      mockClient.textDocumentDidOpen.mockResolvedValue(true);
      const cellUri = CellDocumentUri.of(Cells.cell1);

      await expect(
        notebookClient.textDocumentDidOpen({
          textDocument: {
            uri: cellUri,
            languageId: "python",
            version: 1,
            text: "print('cell')",
          },
        }),
      ).resolves.toBe(true);
      await notebookClient.textDocumentDidClose({
        textDocument: { uri: cellUri },
      });

      expect(mockClient.textDocumentDidOpen).toHaveBeenCalledWith({
        textDocument: {
          uri: "file:///project/__marimo_notebook__.py",
          languageId: "python",
          version: 1,
          text: [
            "# this is a comment",
            "import math",
            "import numpy",
            "print(math.sqrt(4))",
          ].join("\n"),
        },
      });
      expect(mockClient.textDocumentDidClose).toHaveBeenCalledWith({
        textDocument: {
          uri: "file:///project/__marimo_notebook__.py",
        },
      });
    });

    it("reopens the merged document directly after reconnection", async () => {
      const cellUri = CellDocumentUri.of(Cells.cell1);
      await notebookClient.textDocumentDidOpen({
        textDocument: {
          uri: cellUri,
          languageId: "python",
          version: 1,
          text: "print('cell')",
        },
      });
      notifyMock.mockClear();

      await notebookClient.resyncAllDocuments();

      expect(mockClient.initialize).toHaveBeenCalledTimes(1);
      expect(notifyMock).toHaveBeenNthCalledWith(
        1,
        "workspace/didChangeConfiguration",
        { settings: {} },
      );
      expect(notifyMock).toHaveBeenNthCalledWith(2, "textDocument/didOpen", {
        textDocument: {
          uri: "file:///project/__marimo_notebook__.py",
          languageId: "python",
          version: 1,
          text: [
            "# this is a comment",
            "import math",
            "import numpy",
            "print(math.sqrt(4))",
          ].join("\n"),
        },
      });
      expect(mockClient.textDocumentDidOpen).toHaveBeenCalledTimes(1);
    });

    it("does not reopen a notebook with no active editor documents", async () => {
      notifyMock.mockClear();

      await notebookClient.resyncAllDocuments();

      expect(notifyMock).toHaveBeenCalledTimes(1);
      expect(notifyMock).not.toHaveBeenCalledWith(
        "textDocument/didOpen",
        expect.anything(),
      );
    });

    it("keeps the merged document open until its last cell view closes", async () => {
      const cellUri = CellDocumentUri.of(Cells.cell1);
      const openParams: LSP.DidOpenTextDocumentParams = {
        textDocument: {
          uri: cellUri,
          languageId: "python",
          version: 1,
          text: "value = 1",
        },
      };
      await notebookClient.textDocumentDidOpen(openParams);
      await notebookClient.textDocumentDidOpen(openParams);
      await notebookClient.textDocumentDidClose({
        textDocument: { uri: cellUri },
      });
      notifyMock.mockClear();

      await notebookClient.resyncAllDocuments();
      expect(notifyMock).toHaveBeenCalledWith(
        "textDocument/didOpen",
        expect.anything(),
      );

      await notebookClient.textDocumentDidClose({
        textDocument: { uri: cellUri },
      });
      notifyMock.mockClear();
      await notebookClient.resyncAllDocuments();
      expect(notifyMock).not.toHaveBeenCalledWith(
        "textDocument/didOpen",
        expect.anything(),
      );
    });

    it("ignores an unmatched close instead of forwarding it to the underlying client", async () => {
      const cellUri = CellDocumentUri.of(Cells.cell1);

      // No matching textDocumentDidOpen was ever recorded for this cell.
      await notebookClient.textDocumentDidClose({
        textDocument: { uri: cellUri },
      });

      expect(mockClient.textDocumentDidClose).not.toHaveBeenCalled();
    });

    it("does not let an unmatched close of one cell close the document for others", async () => {
      const cellUri1 = CellDocumentUri.of(Cells.cell1);
      const cellUri2 = CellDocumentUri.of(Cells.cell2);
      await notebookClient.textDocumentDidOpen({
        textDocument: {
          uri: cellUri2,
          languageId: "python",
          version: 1,
          text: "import math",
        },
      });

      // A spurious close for a cell that was never opened must not forward a
      // close for the merged document while cell2's view is still open.
      await notebookClient.textDocumentDidClose({
        textDocument: { uri: cellUri1 },
      });

      expect(mockClient.textDocumentDidClose).not.toHaveBeenCalled();
    });

    it("rolls back the open count when the underlying client rejects textDocumentDidOpen", async () => {
      const cellUri = CellDocumentUri.of(Cells.cell1);
      mockClient.textDocumentDidOpen.mockRejectedValueOnce(
        new Error("transport failure"),
      );

      await expect(
        notebookClient.textDocumentDidOpen({
          textDocument: {
            uri: cellUri,
            languageId: "python",
            version: 1,
            text: "value = 1",
          },
        }),
      ).rejects.toThrow("transport failure");

      // The failed open must not leave a phantom reference behind: a
      // subsequent resync should not believe this cell is open.
      notifyMock.mockClear();
      await notebookClient.resyncAllDocuments();
      expect(notifyMock).not.toHaveBeenCalledWith(
        "textDocument/didOpen",
        expect.anything(),
      );
    });

    it("keeps the reference and marks the cell seen when the underlying client reports no fresh open (result === false)", async () => {
      // The vendor client resolves `false` when another view already has the
      // shared merged document open: it did not need to send its own
      // `didOpen`, but the document is genuinely open. This is the common
      // case for every cell after the first one in a notebook, since all
      // cells share the same underlying merged-document URI. It must not be
      // treated like a rejection.
      const cellUri = CellDocumentUri.of(Cells.cell1);
      mockClient.textDocumentDidOpen.mockResolvedValueOnce(false);

      await expect(
        notebookClient.textDocumentDidOpen({
          textDocument: {
            uri: cellUri,
            languageId: "python",
            version: 1,
            text: "value = 1",
          },
        }),
      ).resolves.toBe(false);

      const seenCellDocumentUris = (
        notebookClient as unknown as { seenCellDocumentUris: Set<string> }
      ).seenCellDocumentUris;
      expect(seenCellDocumentUris.has(cellUri)).toBe(true);

      // The reference must still be tracked: closing it forwards a real
      // close instead of being treated as unmatched.
      await notebookClient.textDocumentDidClose({
        textDocument: { uri: cellUri },
      });
      expect(mockClient.textDocumentDidClose).toHaveBeenCalledTimes(1);
    });

    it("does not mark a cell as seen when the underlying client rejects textDocumentDidOpen", async () => {
      const cellUri = CellDocumentUri.of(Cells.cell1);
      mockClient.textDocumentDidOpen.mockRejectedValueOnce(
        new Error("transport failure"),
      );

      await expect(
        notebookClient.textDocumentDidOpen({
          textDocument: {
            uri: cellUri,
            languageId: "python",
            version: 1,
            text: "value = 1",
          },
        }),
      ).rejects.toThrow("transport failure");

      // `seenCellDocumentUris` drives diagnostic clearing; a cell that never
      // successfully opened has no diagnostics to clear and must not be
      // tracked as seen.
      const seenCellDocumentUris = (
        notebookClient as unknown as { seenCellDocumentUris: Set<string> }
      ).seenCellDocumentUris;
      expect(seenCellDocumentUris.has(cellUri)).toBe(false);
    });

    it("does not drop a concurrent open's reference when an earlier open for the same cell rejects", async () => {
      const cellUri = CellDocumentUri.of(Cells.cell1);
      const openParams: LSP.DidOpenTextDocumentParams = {
        textDocument: {
          uri: cellUri,
          languageId: "python",
          version: 1,
          text: "value = 1",
        },
      };

      let rejectFirst!: (error: Error) => void;
      const firstUnderlyingOpen = new Promise<boolean>((_, reject) => {
        rejectFirst = reject;
      });
      let resolveSecond!: (value: boolean) => void;
      const secondUnderlyingOpen = new Promise<boolean>((resolve) => {
        resolveSecond = resolve;
      });
      mockClient.textDocumentDidOpen
        .mockReturnValueOnce(firstUnderlyingOpen)
        .mockReturnValueOnce(secondUnderlyingOpen);

      // Two concurrent opens for the same cell (e.g. a fast remount) both
      // increment the shared count before either underlying call settles.
      const firstCall = notebookClient.textDocumentDidOpen(openParams);
      const secondCall = notebookClient.textDocumentDidOpen(openParams);
      const firstCallOutcome = firstCall.catch((error: Error) => error);

      // The first (stale) open fails; its rollback must not erase the
      // second, still-live open's reference.
      rejectFirst(new Error("transport failure"));
      await firstCallOutcome;

      resolveSecond(true);
      await secondCall;

      await notebookClient.textDocumentDidClose({
        textDocument: { uri: cellUri },
      });
      expect(mockClient.textDocumentDidClose).toHaveBeenCalledTimes(1);
    });

    it("maps safe save notifications and rejects merged save edits", async () => {
      const cellUri = CellDocumentUri.of(Cells.cell1);
      const willSaveParams: LSP.WillSaveTextDocumentParams = {
        textDocument: { uri: cellUri },
        reason: LSP.TextDocumentSaveReason.Manual,
      };

      await notebookClient.textDocumentWillSave(willSaveParams);
      await expect(
        notebookClient.textDocumentWillSaveWaitUntil(willSaveParams),
      ).resolves.toBeNull();
      await notebookClient.textDocumentDidSave({
        textDocument: { uri: cellUri },
        text: "cell text",
      });

      expect(mockClient.textDocumentWillSave).toHaveBeenCalledWith({
        textDocument: {
          uri: "file:///project/__marimo_notebook__.py",
        },
        reason: LSP.TextDocumentSaveReason.Manual,
      });
      expect(mockClient.textDocumentWillSaveWaitUntil).not.toHaveBeenCalled();
      expect(mockClient.textDocumentDidSave).toHaveBeenCalledWith({
        textDocument: {
          uri: "file:///project/__marimo_notebook__.py",
        },
        text: [
          "# this is a comment",
          "import math",
          "import numpy",
          "print(math.sqrt(4))",
        ].join("\n"),
      });
    });
  });

  describe("textDocumentHover", () => {
    it("should transform hover position and range", async () => {
      const hoverParams: LSP.HoverParams = {
        textDocument: { uri: "file:///cell1.py" },
        position: { line: 1, character: 5 },
      };

      const mockHoverResponse: LSP.Hover = {
        contents: {
          kind: "markdown",
          value: "test hover",
        },
        range: {
          start: { line: 2, character: 0 },
          end: { line: 2, character: 5 },
        },
      };

      mockClient.textDocumentHover.mockResolvedValue(mockHoverResponse);

      // Open a document first to set up the lens
      await notebookClient.textDocumentDidOpen({
        textDocument: {
          uri: "file:///cell1.py",
          languageId: "python",
          version: 1,
          text: "test\ncode",
        },
      });

      const result = await notebookClient.textDocumentHover(hoverParams);

      expect(result).toBeDefined();
      expect(result?.contents).toEqual({
        kind: "markdown",
        value: "test hover",
      });
    });

    it("should normalize math content in hover markdown", async () => {
      const hoverParams: LSP.HoverParams = {
        textDocument: { uri: "file:///cell1.py" },
        position: { line: 0, character: 1 },
      };

      const mockHoverResponse: LSP.Hover = {
        contents: {
          kind: "markdown",
          value:
            "For t > 0:\n\n.. math::\n\n\\begin{align*}\nm_t &= \\beta_1 \\cdot g_t\n\\end{align*}",
        },
      };

      mockClient.textDocumentHover.mockResolvedValue(mockHoverResponse);

      await notebookClient.textDocumentDidOpen({
        textDocument: {
          uri: "file:///cell1.py",
          languageId: "python",
          version: 1,
          text: "value = 1",
        },
      });

      const result = await notebookClient.textDocumentHover(hoverParams);
      const contents = result?.contents as LSP.MarkupContent;

      expect(contents.kind).toBe("markdown");
      expect(contents.value).toContain("<marimo-tex");
      expect(contents.value).not.toContain(".. math::");
      expect(contents.value).toContain("\\begin{align*}");
    });

    it("should return null for empty hover contents", async () => {
      const hoverParams: LSP.HoverParams = {
        textDocument: { uri: "file:///cell1.py" },
        position: { line: 0, character: 0 },
      };

      mockClient.textDocumentHover.mockResolvedValue({ contents: "" });

      await notebookClient.textDocumentDidOpen({
        textDocument: {
          uri: "file:///cell1.py",
          languageId: "python",
          version: 1,
          text: "test",
        },
      });

      const result = await notebookClient.textDocumentHover(hoverParams);
      expect(result).toBeNull();
    });
  });

  describe("textDocumentCompletion", () => {
    it("should transform completion position", async () => {
      const completionParams: LSP.CompletionParams = {
        textDocument: { uri: "file:///cell1.py" },
        position: { line: 0, character: 4 },
      };

      const mockCompletionResponse: LSP.CompletionList = {
        isIncomplete: false,
        items: [
          {
            label: "test_completion",
            kind: LSP.CompletionItemKind.Function,
          },
        ],
      };

      mockClient.textDocumentCompletion.mockResolvedValue(
        mockCompletionResponse,
      );

      await notebookClient.textDocumentDidOpen({
        textDocument: {
          uri: "file:///cell1.py",
          languageId: "python",
          version: 1,
          text: "test",
        },
      });

      const result =
        await notebookClient.textDocumentCompletion(completionParams);
      expect(result).toEqual(mockCompletionResponse);
      expect(mockClient.textDocumentCompletion).toHaveBeenCalledWith(
        expect.objectContaining({
          textDocument: { uri: "file:///project/__marimo_notebook__.py" },
        }),
      );
    });

    it("should normalize completion item markdown documentation", async () => {
      const completionParams: LSP.CompletionParams = {
        textDocument: { uri: "file:///cell1.py" },
        position: { line: 0, character: 4 },
      };

      const mockCompletionResponse: LSP.CompletionList = {
        isIncomplete: false,
        items: [
          {
            label: "math_completion",
            kind: LSP.CompletionItemKind.Function,
            documentation: {
              kind: "markdown",
              value: "Compute :math:`x^2`",
            },
          },
        ],
      };

      mockClient.textDocumentCompletion.mockResolvedValue(
        mockCompletionResponse,
      );

      await notebookClient.textDocumentDidOpen({
        textDocument: {
          uri: "file:///cell1.py",
          languageId: "python",
          version: 1,
          text: "math",
        },
      });

      const result =
        await notebookClient.textDocumentCompletion(completionParams);
      const completion = (result as LSP.CompletionList).items[0];
      const documentation = completion?.documentation as LSP.MarkupContent;

      expect(documentation.kind).toBe("markdown");
      expect(documentation.value).toContain("<marimo-tex");
      expect(documentation.value).not.toContain(":math:`");
    });

    it("should normalize completion item plaintext math documentation", async () => {
      const completionParams: LSP.CompletionParams = {
        textDocument: { uri: "file:///cell1.py" },
        position: { line: 0, character: 4 },
      };

      const mockCompletionResponse: LSP.CompletionList = {
        isIncomplete: false,
        items: [
          {
            label: "math_completion_plain",
            kind: LSP.CompletionItemKind.Function,
            documentation: {
              kind: "plaintext",
              value: "For t > 0:\n\n.. math::\n\n    m_t = \\beta_1 \\cdot g_t",
            },
          },
        ],
      };

      mockClient.textDocumentCompletion.mockResolvedValue(
        mockCompletionResponse,
      );

      await notebookClient.textDocumentDidOpen({
        textDocument: {
          uri: "file:///cell1.py",
          languageId: "python",
          version: 1,
          text: "math",
        },
      });

      const result =
        await notebookClient.textDocumentCompletion(completionParams);
      const completion = (result as LSP.CompletionList).items[0];
      const documentation = completion?.documentation as LSP.MarkupContent;

      expect(documentation.kind).toBe("markdown");
      expect(documentation.value).toContain("<marimo-tex");
      expect(documentation.value).not.toContain(".. math::");
    });
  });

  describe("completionItemResolve", () => {
    it("should normalize resolved completion markdown documentation", async () => {
      const unresolvedItem: LSP.CompletionItem = { label: "test" };
      const resolvedItem: LSP.CompletionItem = {
        label: "test",
        documentation: {
          kind: "markdown",
          value: "For t > 0:\n\n.. math::\n\n    m_t = \\beta_1 \\cdot g_t",
        },
      };

      mockClient.completionItemResolve.mockResolvedValue(resolvedItem);

      const result = await notebookClient.completionItemResolve(unresolvedItem);
      const documentation = result.documentation as LSP.MarkupContent;

      expect(documentation.kind).toBe("markdown");
      expect(documentation.value).toContain("<marimo-tex");
      expect(documentation.value).not.toContain(".. math::");
    });
  });

  describe("textDocumentSignatureHelp", () => {
    it("should normalize signature and parameter markdown documentation", async () => {
      const signatureHelpParams: LSP.SignatureHelpParams = {
        textDocument: { uri: "file:///cell1.py" },
        position: { line: 0, character: 3 },
      };

      const mockSignatureHelp: LSP.SignatureHelp = {
        signatures: [
          {
            label: "foo(x)",
            documentation: {
              kind: "markdown",
              value: "Compute :math:`x^2`",
            },
            parameters: [
              {
                label: "x",
                documentation: {
                  kind: "markdown",
                  value:
                    "For t > 0:\n\n.. math::\n\n    m_t = \\beta_1 \\cdot g_t",
                },
              },
            ],
          },
        ],
      };

      mockClient.textDocumentSignatureHelp.mockResolvedValue(mockSignatureHelp);

      await notebookClient.textDocumentDidOpen({
        textDocument: {
          uri: "file:///cell1.py",
          languageId: "python",
          version: 1,
          text: "foo(",
        },
      });

      const result =
        await notebookClient.textDocumentSignatureHelp(signatureHelpParams);
      const signature = result?.signatures[0];
      const signatureDoc = signature?.documentation as LSP.MarkupContent;
      const parameterDoc = signature?.parameters?.[0]
        ?.documentation as LSP.MarkupContent;

      expect(signatureDoc.value).toContain("<marimo-tex");
      expect(signatureDoc.value).not.toContain(":math:`");
      expect(parameterDoc.value).toContain("<marimo-tex");
      expect(parameterDoc.value).not.toContain(".. math::");
    });
  });

  describe("textDocumentRename", () => {
    it("should transform rename position and apply edits to editor views", async () => {
      // Setup mock plugins with editor views
      const mockView1 = new EditorView({
        doc: "# this is a comment",
        extensions: [
          languageAdapterState.init(() => new PythonLanguageAdapter()),
          languageMetadataField.init(() => ({})),
          languageServerWithClient({
            client: mockClient as unknown as LanguageServerClient,
            documentUri: CellDocumentUri.of(Cells.cell1),
          }),
        ],
      });
      expect(mockView1.state.doc.toString()).toBe("# this is a comment");

      const mockView2 = new EditorView({
        doc: "import math\nimport numpy",
        extensions: [
          languageAdapterState.init(() => new PythonLanguageAdapter()),
          languageMetadataField.init(() => ({})),
          languageServerWithClient({
            client: mockClient as unknown as LanguageServerClient,
            documentUri: CellDocumentUri.of(Cells.cell2),
          }),
        ],
      });
      expect(mockView2.state.doc.toString()).toBe("import math\nimport numpy");

      const mockView3 = new EditorView({
        doc: "print(math.sqrt(4))",
        extensions: [
          languageAdapterState.init(() => new PythonLanguageAdapter()),
          languageMetadataField.init(() => ({})),
          languageServerWithClient({
            client: mockClient as unknown as LanguageServerClient,
            documentUri: CellDocumentUri.of(Cells.cell3),
          }),
        ],
      });
      expect(mockView3.state.doc.toString()).toBe("print(math.sqrt(4))");

      replaceNotebookEditors(notebookClient, () => ({
        [Cells.cell1]: mockView1,
        [Cells.cell2]: mockView2,
        [Cells.cell3]: mockView3,
      }));

      // Setup rename params
      const renameParams: LSP.RenameParams = {
        textDocument: { uri: CellDocumentUri.of(Cells.cell2) },
        position: { line: 0, character: 7 },
        newName: "renamed_math",
      };

      // Open a document first to set up the lens
      await notebookClient.textDocumentDidOpen({
        textDocument: {
          uri: CellDocumentUri.of(Cells.cell2),
          languageId: "python",
          version: 1,
          text: "import math\nimport numpy",
        },
      });

      // Mock the response from the language server
      const mockRenameResponse: LSP.WorkspaceEdit = {
        documentChanges: [
          {
            textDocument: {
              uri: "file:///__marimo_notebook__.py",
              version: 1,
            },
            edits: [
              {
                range: {
                  start: { line: 0, character: 0 },
                  end: { line: 3, character: 17 },
                },
                newText:
                  "# this is a comment\nimport renamed_math\nimport numpy\nprint(renamed_math.sqrt(4))",
              },
            ],
          },
        ],
      };

      mockClient.textDocumentRename = vi
        .fn()
        .mockResolvedValue(mockRenameResponse);

      // Call rename
      const result = await notebookClient.textDocumentRename(renameParams);
      expect(result).toMatchInlineSnapshot(`
        {
          "documentChanges": [
            {
              "edits": [],
              "textDocument": {
                "uri": "file:///cell2",
                "version": 0,
              },
            },
          ],
        }
      `);

      expect(mockView2.state.doc.toString()).toBe(
        "import renamed_math\nimport numpy",
      );
      expect(mockView1.state.doc.toString()).toBe("# this is a comment");
    });

    it("should return null for invalid cell document URIs", async () => {
      const invalidParams: LSP.RenameParams = {
        textDocument: { uri: "file:///invalid.py" },
        position: { line: 0, character: 0 },
        newName: "new_name",
      };

      const result = await notebookClient.textDocumentRename(invalidParams);
      expect(result).toBeNull();
    });

    it("should return null when no lens is found", async () => {
      const renameParams: LSP.RenameParams = {
        textDocument: { uri: CellDocumentUri.of(Cells.cell1) },
        position: { line: 0, character: 0 },
        newName: "new_name",
      };

      const result = await notebookClient.textDocumentRename(renameParams);
      expect(result).toBeNull();
    });

    it("should return the original response when edits are not as expected", async () => {
      // Setup response with multiple edits
      const multiEditResponse: LSP.WorkspaceEdit = {
        documentChanges: [
          {
            textDocument: {
              uri: "file:///__marimo_notebook__.py",
              version: 1,
            },
            edits: [
              {
                range: {
                  start: { line: 0, character: 0 },
                  end: { line: 0, character: 5 },
                },
                newText: "edit1",
              },
              {
                range: {
                  start: { line: 1, character: 0 },
                  end: { line: 1, character: 5 },
                },
                newText: "edit2",
              },
            ],
          },
        ],
      };

      mockClient.textDocumentRename = vi
        .fn()
        .mockResolvedValue(multiEditResponse);

      // Open a document first to set up the lens
      await notebookClient.textDocumentDidOpen({
        textDocument: {
          uri: CellDocumentUri.of(Cells.cell1),
          languageId: "python",
          version: 1,
          text: "test",
        },
      });

      const renameParams: LSP.RenameParams = {
        textDocument: { uri: CellDocumentUri.of(Cells.cell1) },
        position: { line: 0, character: 0 },
        newName: "new_name",
      };

      const result = await notebookClient.textDocumentRename(renameParams);

      // Should return the original response when edits don't meet expectations
      expect(result).toEqual(multiEditResponse);
    });

    it("should return the original response when edits don't have newText property", async () => {
      // Setup response with an edit that doesn't have newText
      const invalidEditResponse: LSP.WorkspaceEdit = {
        documentChanges: [
          {
            textDocument: {
              uri: "file:///__marimo_notebook__.py",
              version: 1,
            },
            edits: [
              {
                range: {
                  start: { line: 0, character: 0 },
                  end: { line: 0, character: 5 },
                },
                // Missing newText property
              } as unknown as LSP.TextEdit,
            ],
          },
        ],
      };

      mockClient.textDocumentRename = vi
        .fn()
        .mockResolvedValue(invalidEditResponse);

      // Open a document first to set up the lens
      await notebookClient.textDocumentDidOpen({
        textDocument: {
          uri: CellDocumentUri.of(Cells.cell1),
          languageId: "python",
          version: 1,
          text: "test",
        },
      });

      const renameParams: LSP.RenameParams = {
        textDocument: { uri: CellDocumentUri.of(Cells.cell1) },
        position: { line: 0, character: 0 },
        newName: "new_name",
      };

      const result = await notebookClient.textDocumentRename(renameParams);

      // Should return the original response when edits don't have proper properties
      expect(result).toEqual(invalidEditResponse);
    });

    it("should handle raw strings with markdown content during rename (issue #7377)", async () => {
      // Setup mock plugins with editor views
      const markdownCell = 'mo.md(r"""\n# Header\n""")';
      const variableCell = "a = 'Test'";

      const mockView1 = new EditorView({
        doc: "import marimo as mo",
        extensions: [
          languageAdapterState.init(() => new PythonLanguageAdapter()),
          languageMetadataField.init(() => ({})),
          languageServerWithClient({
            client: mockClient as unknown as LanguageServerClient,
            documentUri: CellDocumentUri.of(Cells.cell1),
          }),
        ],
      });

      const mockView2 = new EditorView({
        doc: markdownCell,
        extensions: [
          languageAdapterState.init(() => new PythonLanguageAdapter()),
          languageMetadataField.init(() => ({})),
          languageServerWithClient({
            client: mockClient as unknown as LanguageServerClient,
            documentUri: CellDocumentUri.of(Cells.cell2),
          }),
        ],
      });

      const mockView3 = new EditorView({
        doc: variableCell,
        extensions: [
          languageAdapterState.init(() => new PythonLanguageAdapter()),
          languageMetadataField.init(() => ({})),
          languageServerWithClient({
            client: mockClient as unknown as LanguageServerClient,
            documentUri: CellDocumentUri.of(Cells.cell3),
          }),
        ],
      });

      replaceNotebookEditors(notebookClient, () => ({
        [Cells.cell1]: mockView1,
        [Cells.cell2]: mockView2,
        [Cells.cell3]: mockView3,
      }));

      // Update the mock to return the correct codes
      vi.spyOn(store, "get").mockImplementation((atom) => {
        if (atom === topologicalCodesAtom) {
          return {
            cellIds: [Cells.cell1, Cells.cell2, Cells.cell3],
            codes: {
              [Cells.cell1]: "import marimo as mo",
              [Cells.cell2]: markdownCell,
              [Cells.cell3]: variableCell,
            },
          };
        }
        return undefined;
      });

      // Setup rename params - renaming variable 'a' in cell3
      const renameParams: LSP.RenameParams = {
        textDocument: { uri: CellDocumentUri.of(Cells.cell3) },
        position: { line: 0, character: 0 }, // position of 'a'
        newName: "b",
      };

      // Open a document first to set up the lens
      await notebookClient.textDocumentDidOpen({
        textDocument: {
          uri: CellDocumentUri.of(Cells.cell3),
          languageId: "python",
          version: 1,
          text: variableCell,
        },
      });

      // Mock the response from the language server
      // The merged document includes all cells (5 lines total):
      // Line 0: "import marimo as mo"
      // Line 1: "mo.md(r\"\"\""
      // Line 2: "# Header"
      // Line 3: "\"\"\")"
      // Line 4: "a = 'Test'"
      // When renaming variable 'a' to 'b', the entire document is returned
      const mockRenameResponse: LSP.WorkspaceEdit = {
        documentChanges: [
          {
            textDocument: {
              uri: "file:///__marimo_notebook__.py",
              version: 1,
            },
            edits: [
              {
                range: {
                  start: { line: 0, character: 0 },
                  end: { line: 4, character: 10 },
                },
                // The renamed text should preserve all cells including markdown
                newText:
                  'import marimo as mo\nmo.md(r"""\n# Header\n""")\nb = \'Test\'',
              },
            ],
          },
        ],
      };

      mockClient.textDocumentRename = vi
        .fn()
        .mockResolvedValue(mockRenameResponse);

      // Call rename
      await notebookClient.textDocumentRename(renameParams);

      // Verify that the markdown cell was NOT corrupted and remains unchanged
      expect(mockView2.state.doc.toString()).toBe(markdownCell);
      // Verify that the variable cell was renamed
      expect(mockView3.state.doc.toString()).toBe("b = 'Test'");
      // Verify that the import cell was not changed
      expect(mockView1.state.doc.toString()).toBe("import marimo as mo");
    });

    it("should only rename private variables in the current cell (issue #7810)", async () => {
      // Setup editor views - both cells have a private variable _x
      const cell1Code = "_x = 1\nprint(_x)";
      const cell2Code = "_x = 2\nprint(_x)";

      const mockView1 = new EditorView({
        doc: cell1Code,
        extensions: [
          languageAdapterState.init(() => new PythonLanguageAdapter()),
          languageMetadataField.init(() => ({})),
          languageServerWithClient({
            client: mockClient as unknown as LanguageServerClient,
            documentUri: CellDocumentUri.of(Cells.cell1),
          }),
        ],
      });

      const mockView2 = new EditorView({
        doc: cell2Code,
        extensions: [
          languageAdapterState.init(() => new PythonLanguageAdapter()),
          languageMetadataField.init(() => ({})),
          languageServerWithClient({
            client: mockClient as unknown as LanguageServerClient,
            documentUri: CellDocumentUri.of(Cells.cell2),
          }),
        ],
      });

      replaceNotebookEditors(notebookClient, () => ({
        [Cells.cell1]: mockView1,
        [Cells.cell2]: mockView2,
      }));

      // Update the mock to return the correct codes
      vi.spyOn(store, "get").mockImplementation((atom) => {
        if (atom === topologicalCodesAtom) {
          return {
            cellIds: [Cells.cell1, Cells.cell2],
            codes: {
              [Cells.cell1]: cell1Code,
              [Cells.cell2]: cell2Code,
            },
          };
        }
        return undefined;
      });

      // Setup rename params - renaming _x in cell1
      const renameParams: LSP.RenameParams = {
        textDocument: { uri: CellDocumentUri.of(Cells.cell1) },
        position: { line: 0, character: 0 }, // position of '_x'
        newName: "_y",
      };

      // Open a document first to set up the lens
      await notebookClient.textDocumentDidOpen({
        textDocument: {
          uri: CellDocumentUri.of(Cells.cell1),
          languageId: "python",
          version: 1,
          text: cell1Code,
        },
      });

      // Mock the response from the language server
      // The LSP server would rename _x in BOTH cells (since it sees the merged doc)
      const mockRenameResponse: LSP.WorkspaceEdit = {
        documentChanges: [
          {
            textDocument: {
              uri: "file:///__marimo_notebook__.py",
              version: 1,
            },
            edits: [
              {
                range: {
                  start: { line: 0, character: 0 },
                  end: { line: 3, character: 10 },
                },
                // LSP renames _x to _y in both cells
                newText: "_y = 1\nprint(_y)\n_y = 2\nprint(_y)",
              },
            ],
          },
        ],
      };

      mockClient.textDocumentRename = vi
        .fn()
        .mockResolvedValue(mockRenameResponse);

      // Call rename
      await notebookClient.textDocumentRename(renameParams);

      // The fix: only cell1 should be renamed, cell2 should remain unchanged
      // because private variables are cell-local in marimo
      expect(mockView1.state.doc.toString()).toBe("_y = 1\nprint(_y)");
      expect(mockView2.state.doc.toString()).toBe("_x = 2\nprint(_x)");
    });
  });

  describe("diagnostics handling", () => {
    it("forwards malformed diagnostic notifications without throwing", () => {
      const forwardedNotification = vi.fn();
      mockClient.processNotification = forwardedNotification;
      notebookClient.patchProcessNotification();

      const malformedNotification: ClientNotification = {
        method: "textDocument/publishDiagnostics",
        params: {
          uri: "file:///__marimo__.py",
          diagnostics: [{ message: "Missing a range" }],
        },
      };

      expect(() => {
        mockClient.processNotification(malformedNotification);
      }).not.toThrow();
      expect(forwardedNotification).toHaveBeenCalledWith(malformedNotification);
    });

    it("should transform diagnostic ranges and filter out-of-bounds diagnostics", async () => {
      // Mock processNotification to capture the transformed diagnostics
      const capturedDiagnostics: LSP.PublishDiagnosticsParams[] = [];
      mockClient.processNotification = vi
        .fn()
        .mockImplementation((notification: ClientNotification) => {
          if (isPublishDiagnosticsNotification(notification)) {
            capturedDiagnostics.push(notification.params);
          }
        });

      // Call patch since we changed processNotification
      notebookClient.patchProcessNotification();

      // Open documents for multiple cells so they get tracked
      await notebookClient.textDocumentDidOpen({
        textDocument: {
          uri: CellDocumentUri.of(Cells.cell1),
          languageId: "python",
          version: 1,
          text: "import math\nimport numpy",
        },
      });

      await notebookClient.textDocumentDidOpen({
        textDocument: {
          uri: CellDocumentUri.of(Cells.cell2),
          languageId: "python",
          version: 1,
          text: "import math\nimport numpy",
        },
      });

      // Simulate receiving diagnostics
      const diagnosticsNotification = {
        method: "textDocument/publishDiagnostics",
        params: {
          uri: "file:///__marimo__.py",
          version: 1,
          diagnostics: [
            {
              range: {
                start: { line: 2, character: 0 },
                end: { line: 2, character: 4 },
              },
              message: "Test diagnostic",
              severity: LSP.DiagnosticSeverity.Error,
            },
            // Out of bounds diagnostic that should be filtered
            {
              range: {
                start: { line: 10, character: 0 },
                end: { line: 10, character: 4 },
              },
              message: "Out of bounds",
              severity: LSP.DiagnosticSeverity.Error,
            },
          ],
        },
      };

      mockClient.processNotification(diagnosticsNotification);

      expect(capturedDiagnostics).toHaveLength(2);
      expect(capturedDiagnostics[0].diagnostics).toHaveLength(1);
      expect(capturedDiagnostics[0].diagnostics[0].range).toEqual({
        start: { line: 1, character: 0 },
        end: { line: 1, character: 4 },
      });

      // Rest are cleared
      expect(capturedDiagnostics[1].diagnostics).toHaveLength(0);
    });

    it("should map relatedInformation out of merged-document coordinates", async () => {
      const capturedDiagnostics: LSP.PublishDiagnosticsParams[] = [];
      mockClient.processNotification = vi
        .fn()
        .mockImplementation((notification: ClientNotification) => {
          if (isPublishDiagnosticsNotification(notification)) {
            capturedDiagnostics.push(notification.params);
          }
        });
      notebookClient.patchProcessNotification();

      await notebookClient.textDocumentDidOpen({
        textDocument: {
          uri: CellDocumentUri.of(Cells.cell3),
          languageId: "python",
          version: 1,
          text: "print(math.sqrt(4))",
        },
      });

      // Merged doc: line 0 -> cell1, lines 1-2 -> cell2, line 3 -> cell3
      mockClient.processNotification({
        method: "textDocument/publishDiagnostics",
        params: {
          uri: notebookClient.documentUri,
          version: 1,
          diagnostics: [
            {
              range: {
                start: { line: 3, character: 0 },
                end: { line: 3, character: 5 },
              },
              message: "Shadowed import",
              severity: LSP.DiagnosticSeverity.Warning,
              relatedInformation: [
                {
                  location: {
                    uri: notebookClient.documentUri,
                    range: {
                      start: { line: 1, character: 7 },
                      end: { line: 1, character: 11 },
                    },
                  },
                  message: "declared here",
                },
                {
                  location: {
                    uri: "file:///site-packages/math.pyi",
                    range: {
                      start: { line: 9, character: 0 },
                      end: { line: 9, character: 4 },
                    },
                  },
                  message: "stub definition",
                },
              ],
            },
          ],
        },
      });

      const forwarded = capturedDiagnostics.find(
        (params) => params.diagnostics.length > 0,
      );
      expect(forwarded?.uri).toBe(CellDocumentUri.of(Cells.cell3));
      expect(forwarded?.diagnostics[0].relatedInformation).toEqual([
        {
          location: {
            uri: CellDocumentUri.of(Cells.cell2),
            range: {
              start: { line: 0, character: 7 },
              end: { line: 0, character: 11 },
            },
          },
          message: "declared here",
        },
        {
          location: {
            uri: "file:///site-packages/math.pyi",
            range: {
              start: { line: 9, character: 0 },
              end: { line: 9, character: 4 },
            },
          },
          message: "stub definition",
        },
      ]);
    });

    it("should keep diagnostics with unusable relatedInformation entries", async () => {
      const capturedDiagnostics: LSP.PublishDiagnosticsParams[] = [];
      mockClient.processNotification = vi
        .fn()
        .mockImplementation((notification: ClientNotification) => {
          if (isPublishDiagnosticsNotification(notification)) {
            capturedDiagnostics.push(notification.params);
          }
        });
      notebookClient.patchProcessNotification();

      await notebookClient.textDocumentDidOpen({
        textDocument: {
          uri: CellDocumentUri.of(Cells.cell3),
          languageId: "python",
          version: 1,
          text: "print(math.sqrt(4))",
        },
      });

      expect(() => {
        mockClient.processNotification({
          method: "textDocument/publishDiagnostics",
          params: {
            uri: notebookClient.documentUri,
            version: 1,
            diagnostics: [
              {
                range: {
                  start: { line: 3, character: 0 },
                  end: { line: 3, character: 5 },
                },
                message: "Shadowed import",
                // `isDiagnostic` doesn't reach these, so a server can hand us
                // entries that aren't objects at all.
                relatedInformation: [
                  null,
                  { message: "no location" },
                ] as unknown as LSP.DiagnosticRelatedInformation[],
              },
            ],
          },
        });
      }).not.toThrow();

      const forwarded = capturedDiagnostics.find(
        (params) => params.diagnostics.length > 0,
      );
      expect(forwarded?.uri).toBe(CellDocumentUri.of(Cells.cell3));
      expect(forwarded?.diagnostics[0].message).toBe("Shadowed import");
    });

    it("should clear diagnostics for all cells when receiving empty diagnostics", async () => {
      await notebookClient.sync();

      const seenNotifications: LSP.PublishDiagnosticsParams[] = [];
      mockClient.processNotification = vi
        .fn()
        .mockImplementation((notification: ClientNotification) => {
          if (isPublishDiagnosticsNotification(notification)) {
            seenNotifications.push(notification.params);
          }
        });

      notebookClient.patchProcessNotification();

      // Open documents so they get tracked
      await notebookClient.textDocumentDidOpen({
        textDocument: {
          uri: CellDocumentUri.of(Cells.cell1),
          languageId: "python",
          version: 1,
          text: "import math\nimport numpy",
        },
      });

      await notebookClient.textDocumentDidOpen({
        textDocument: {
          uri: CellDocumentUri.of(Cells.cell2),
          languageId: "python",
          version: 1,
          text: "import math\nimport numpy",
        },
      });

      // Simulate receiving empty diagnostics
      const emptyDiagnosticsNotification = {
        method: "textDocument/publishDiagnostics",
        params: {
          uri: "file:///__marimo__.py",
          version: 1,
          diagnostics: [],
        },
      };

      mockClient.processNotification(emptyDiagnosticsNotification);

      expect(seenNotifications.length).toBeGreaterThan(0);
      seenNotifications.forEach((notification) => {
        expect(notification.diagnostics).toHaveLength(0);
      });
    });

    it("should handle diagnostics across multiple cells", async () => {
      const seenNotifications = new Map<string, LSP.PublishDiagnosticsParams>();
      mockClient.processNotification = vi
        .fn()
        .mockImplementation((notification: ClientNotification) => {
          if (isPublishDiagnosticsNotification(notification)) {
            seenNotifications.set(notification.params.uri, notification.params);
          }
        });

      notebookClient.patchProcessNotification();

      // Open documents for multiple cells so they get tracked
      await notebookClient.textDocumentDidOpen({
        textDocument: {
          uri: CellDocumentUri.of(Cells.cell1),
          languageId: "python",
          version: 1,
          text: "import math\nimport numpy",
        },
      });

      await notebookClient.textDocumentDidOpen({
        textDocument: {
          uri: CellDocumentUri.of(Cells.cell2),
          languageId: "python",
          version: 1,
          text: "import math\nimport numpy",
        },
      });

      // Simulate receiving diagnostics for multiple cells
      const multiCellDiagnosticsNotification = {
        method: "textDocument/publishDiagnostics",
        params: {
          uri: "file:///__marimo__.py",
          version: 1,
          diagnostics: [
            {
              range: {
                start: { line: 0, character: 0 },
                end: { line: 0, character: 4 },
              },
              message: "Cell 1 diagnostic",
              severity: LSP.DiagnosticSeverity.Error,
            },
            {
              range: {
                start: { line: 2, character: 0 },
                end: { line: 2, character: 4 },
              },
              message: "Cell 2 diagnostic",
              severity: LSP.DiagnosticSeverity.Warning,
            },
          ],
        },
      };

      mockClient.processNotification(multiCellDiagnosticsNotification);

      expect(seenNotifications.size).toBe(2);
      const cell1Uri = CellDocumentUri.of(Cells.cell1);
      const cell2Uri = CellDocumentUri.of(Cells.cell2);

      expect(seenNotifications.get(cell1Uri)?.diagnostics).toHaveLength(1);
      expect(seenNotifications.get(cell2Uri)?.diagnostics).toHaveLength(1);
      expect(seenNotifications.get(cell1Uri)?.diagnostics[0].message).toBe(
        "Cell 1 diagnostic",
      );
      expect(seenNotifications.get(cell2Uri)?.diagnostics[0].message).toBe(
        "Cell 2 diagnostic",
      );
    });

    it("should handle version updates in textDocumentDidChange", async () => {
      await notebookClient.textDocumentDidChange({
        textDocument: {
          uri: CellDocumentUri.of(Cells.cell1),
          version: 5,
        },
        contentChanges: [{ text: "new code" }],
      });

      expect(mockClient.textDocumentDidChange).toHaveBeenCalledWith({
        textDocument: {
          uri: "file:///project/__marimo_notebook__.py",
          version: expect.any(Number),
        },
        contentChanges: [
          {
            text: [
              "# this is a comment",
              "import math",
              "import numpy",
              "print(math.sqrt(4))",
            ].join("\n"),
          },
        ],
      });
    });
  });

  describe("sync returns lens to prevent race conditions", () => {
    it("should return the lens used for synchronization", async () => {
      mockClient.textDocumentDidChange = vi
        .fn()
        .mockImplementation((params) => params);

      const result = await notebookClient.sync();

      // sync() should return both params and the lens
      expect(result).toHaveProperty("params");
      expect(result).toHaveProperty("lens");
      expect(result.lens.cellIds).toEqual([
        Cells.cell1,
        Cells.cell2,
        Cells.cell3,
      ]);
      expect(result.lens.mergedText).toContain("# this is a comment");
    });

    it("should return consistent lens even when called multiple times rapidly", async () => {
      mockClient.textDocumentDidChange = vi
        .fn()
        .mockImplementation((params) => params);

      // Call sync multiple times rapidly
      const [result1, result2, result3] = await Promise.all([
        notebookClient.sync(),
        notebookClient.sync(),
        notebookClient.sync(),
      ]);

      // All should return the same lens content (memoized)
      expect(result1.lens.mergedText).toBe(result2.lens.mergedText);
      expect(result2.lens.mergedText).toBe(result3.lens.mergedText);
    });
  });

  describe("diagnostic tracking isolation", () => {
    it("does not leak opened cell state between notebook clients", async () => {
      await notebookClient.textDocumentDidOpen({
        textDocument: {
          uri: CellDocumentUri.of(Cells.cell1),
          languageId: "python",
          version: 1,
          text: "code1",
        },
      });

      const forwardedNotification = vi.fn();
      const isolatedClient: Mocked<TestLanguageServerClient> = {
        ...mockClient,
        processNotification: forwardedNotification,
        notify: vi.fn(),
      };
      const isolatedNotebookClient = new NotebookLanguageServerClient(
        isolatedClient,
        {},
        () => ({}),
      );
      await isolatedNotebookClient.sync();
      isolatedNotebookClient.patchProcessNotification();

      isolatedClient.processNotification({
        method: "textDocument/publishDiagnostics",
        params: {
          uri: "file:///project/__marimo_notebook__.py",
          version: 1,
          diagnostics: [],
        },
      });

      expect(forwardedNotification).not.toHaveBeenCalled();
    });
  });

  describe("initialization and configuration", () => {
    it("should send configuration after initialization", async () => {
      const configNotifications: Array<{
        method: string;
        params: unknown;
      }> = [];
      mockClient.notify = vi.fn().mockImplementation(async (method, params) => {
        configNotifications.push({ method, params });
      });

      // Create a new client to trigger initialization
      const client = new NotebookLanguageServerClient(mockClient, {});
      await client.initialize();

      expect(configNotifications[0]).toMatchInlineSnapshot(`
        {
          "method": "workspace/didChangeConfiguration",
          "params": {
            "settings": {},
          },
        }
      `);
    });
  });
});
