/* Copyright 2026 Marimo. All rights reserved. */
export const Objects = {
  EMPTY: Object.freeze({}) as Record<string, never>,

  mapValues<T, U, K extends string | number>(
    obj: Record<K, T>,
    mapper: (value: T, key: K) => U,
  ): Record<K, U> {
    if (!obj) {
      return obj as Record<K, U>;
    }

    return Objects.fromEntries(
      Objects.entries(obj).map(([key, value]) => [key, mapper(value, key)]),
    );
  },
  /**
   * Type-safe Object.fromEntries
   */
  fromEntries<K extends string | number, V>(obj: [K, V][]): Record<K, V> {
    return Object.fromEntries(obj) as Record<K, V>;
  },
  /**
   * Type-safe Object.entries
   */
  entries<K extends string | number, V>(obj: Record<K, V>): [K, V][] {
    return Object.entries(obj) as [K, V][];
  },
  /**
   * Type-safe Object.keys
   */
  keys<K extends string | number>(obj: Record<K, unknown>): K[] {
    return Object.keys(obj) as K[];
  },
  size<K extends string | number>(obj: Record<K, unknown>): number {
    return Object.keys(obj).length;
  },
  /**
   * Type-safe keyBy
   */
  keyBy<T, K extends string | number>(
    items: T[],
    toKey: (item: T) => K | undefined,
  ): Record<K, T> {
    const result: Record<K, T> = {} as Record<K, T>;
    for (const item of items) {
      const key = toKey(item);
      if (key === undefined) {
        continue;
      }
      result[key] = item;
    }
    return result;
  },
  /**
   * Collect
   */
  collect<T, V, K extends string | number = string>(
    items: T[],
    key: (item: NoInfer<T>) => K,
    mapper: (item: NoInfer<T>) => V,
  ): Record<K, V> {
    return Objects.mapValues(Objects.keyBy(items, key), mapper);
  },
  /**
   * Type-safe groupBy
   */
  groupBy<T, K extends string | number, V>(
    items: T[],
    toKey: (item: T) => K | undefined,
    toValue: (item: T) => V,
  ): Record<K, V[]> {
    const result: Record<K, V[]> = {} as Record<K, V[]>;
    for (const item of items) {
      const key = toKey(item);
      if (key === undefined) {
        continue;
      }
      const value = toValue(item);
      if (key in result) {
        result[key].push(value);
      } else {
        result[key] = [value];
      }
    }
    return result;
  },
  filter<K extends string | number, V>(
    obj: Record<K, V>,
    predicate: (value: V, key: K) => boolean,
  ): Record<K, V> {
    const result: Record<K, V> = {} as Record<K, V>;
    for (const [key, value] of Objects.entries(obj)) {
      if (predicate(value, key)) {
        result[key] = obj[key];
      }
    }
    return result;
  },

  omit<V extends object, K extends keyof V>(
    obj: V,
    keys: K[] | Set<K>,
  ): Partial<V> {
    const set = new Set<K>(keys);
    return Objects.filter(obj, (_, key) => !set.has(key));
  },

  // oxlint-disable-next-line typescript/no-explicit-any
  pick<V extends Record<string, any>, K extends string>(
    obj: V,
    keys: readonly K[],
  ): Pick<V, K & keyof V> {
    const result = {} as Record<string, unknown>;
    for (const key of keys) {
      if (Object.hasOwn(obj, key)) {
        result[key] = obj[key];
      }
    }
    return result as Pick<V, K & keyof V>;
  },
};
